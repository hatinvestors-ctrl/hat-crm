
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/daily-mls-sweep.mjs
var SUPABASE_PROJECT_REF = process.env.SUPABASE_PROJECT_REF || "pyrgotfotmwazigewlke";
var SUPABASE_PAT = process.env.SUPABASE_PAT;
var RENTCAST_API_KEY = process.env.RENTCAST_API_KEY;
var TERMINAL_STATUSES = "('sold','dead_lead','rejected_not_accepted','not_in_buy_box','sequence_completed')";
async function sql(query) {
  const r = await fetch(`https://api.supabase.com/v1/projects/${SUPABASE_PROJECT_REF}/database/query`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SUPABASE_PAT}`, "Content-Type": "application/json" },
    body: JSON.stringify({ query })
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`SQL error ${r.status}: ${text}`);
  return JSON.parse(text);
}
function workspaceCurrentHour(timezone) {
  try {
    const fmt = new Intl.DateTimeFormat("en-US", { hour: "numeric", hour12: false, timeZone: timezone || "Asia/Jerusalem" });
    const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
    const hourPart = parts.find((p) => p.type === "hour");
    return Number(hourPart?.value ?? (/* @__PURE__ */ new Date()).getUTCHours());
  } catch (_) {
    return (/* @__PURE__ */ new Date()).getUTCHours();
  }
}
async function enrichOne(leadId) {
  const r = await fetch(`https://${process.env.URL?.replace(/^https?:\/\//, "") || "localhost:8888"}/.netlify/functions/enrich-lead`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ lead_id: leadId, force: true })
  });
  return r.ok;
}
var daily_mls_sweep_default = async () => {
  if (!SUPABASE_PAT || !RENTCAST_API_KEY) {
    return new Response(JSON.stringify({ ok: false, error: "Missing env vars" }), { status: 500 });
  }
  const workspaces = await sql(`select id, name, settings from public.workspaces where (settings->>'mls_sweep_enabled')::boolean = true and coalesce((settings->>'mls_paused')::boolean, false) = false`);
  const results = [];
  for (const w of workspaces) {
    const tz = w.settings?.mls_sweep_timezone || "Asia/Jerusalem";
    const targetHour = Number(w.settings?.mls_sweep_hour ?? 5);
    const currentHour = workspaceCurrentHour(tz);
    if (currentHour !== targetHour) {
      results.push({ workspace: w.name, skipped: true, reason: `current ${tz} hour ${currentHour} \u2260 target ${targetHour}` });
      continue;
    }
    const cap = Number(w.settings?.mls_sweep_max_leads ?? 100);
    const rows = await sql(`
      select id from public.leads
      where workspace_id = '${w.id}'
        and status not in ${TERMINAL_STATUSES}
        and (mls_last_checked is null or mls_last_checked < now() - interval '12 hours')
      order by mls_last_checked asc nulls first
      limit ${cap}
    `);
    let ok = 0, fail = 0;
    for (const r of rows) {
      try {
        const success = await enrichOne(r.id);
        if (success) ok++;
        else fail++;
      } catch (_) {
        fail++;
      }
    }
    results.push({ workspace: w.name, processed: ok, failed: fail, total: rows.length });
  }
  return new Response(JSON.stringify({ ok: true, ran_at: (/* @__PURE__ */ new Date()).toISOString(), results }), {
    status: 200,
    headers: { "content-type": "application/json" }
  });
};
var config = {
  schedule: "7 * * * *"
};
export {
  config,
  daily_mls_sweep_default as default
};
